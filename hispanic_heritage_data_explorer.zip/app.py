import io, math
from datetime import date

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import streamlit as st
import sympy as sp
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table

st.set_page_config(page_title="Hispanic Heritage Historical Data Explorer", page_icon="🌎", layout="wide")
st.markdown("""
<style>
.hero{padding:1.25rem;border-radius:18px;background:linear-gradient(110deg,#fff0c8,#f9dfe7,#dff3e7);border:1px solid #e8cdb8}
.hero h1{color:#713b48;margin:0}.hero p{margin:.35rem 0;color:#35424a}
div[data-testid="stMetric"]{background:#fff9ee;padding:.65rem;border-radius:12px;border:1px solid #f0dfc5}
</style>
<div class="hero"><h1>🌎 Hispanic Heritage Historical Data Explorer</h1>
<p><b>HISPANIC HERITAGE DATA LAB</b> · Discover history through authentic data and mathematics.</p>
<p>🎨 Mexico · Brazil · Argentina · Colombia · Chile · Peru · Venezuela · Ecuador · Uruguay</p></div>
""", unsafe_allow_html=True)

COUNTRIES={"Mexico":"MX","Brazil":"BR","Argentina":"AR","Colombia":"CO","Chile":"CL","Peru":"PE","Venezuela":"VE","Ecuador":"EC","Uruguay":"UY"}
INDICATORS={
"Life expectancy at birth":"SP.DYN.LE00.IN",
"Unemployment, national estimate":"SL.UEM.TOTL.NE.ZS",
"GDP per capita (current US$)":"NY.GDP.PCAP.CD",
"Crude birth rate (per 1,000 people)":"SP.DYN.CBRT.IN",
"Net migration":"SM.POP.NETM",
"Intentional homicide rate (per 100,000 people)":"VC.IHR.PSRC.P5",
"Consumer price inflation (annual %)":"FP.CPI.TOTL.ZG",
"Central government debt (% of GDP)":"GC.DOD.TOTL.GD.ZS",
"Total reserves including gold (current US$)":"FI.RES.TOTL.CD",
"External balance on goods and services (% of GDP)":"NE.RSB.GNFS.ZS"}
DEFS={
"Life expectancy at birth":"Expected years a newborn would live if current age-specific mortality rates continued. Unit: years.",
"Unemployment, national estimate":"Unemployed people as a share of the labor force. Unit: percent of labor force.",
"GDP per capita (current US$)":"Gross domestic product divided by population, in current US dollars; not average wealth or household income.",
"Crude birth rate (per 1,000 people)":"Live births per year per 1,000 people; this is a rate, not a birth count.",
"Net migration":"Net number of migrants (immigrants minus emigrants); not an emigration count.",
"Intentional homicide rate (per 100,000 people)":"Intentional homicide victims per 100,000 people.",
"Consumer price inflation (annual %)":"Annual percentage change in the consumer price index.",
"Central government debt (% of GDP)":"Central government debt as a percentage of GDP.",
"Total reserves including gold (current US$)":"Total reserves including gold, in current US dollars.",
"External balance on goods and services (% of GDP)":"External balance on goods and services as a percentage of GDP."}
UNITS={
"Life expectancy at birth":"years","Unemployment, national estimate":"% of labor force",
"GDP per capita (current US$)":"current US$ per person","Crude birth rate (per 1,000 people)":"births per 1,000 people",
"Net migration":"people (net)","Intentional homicide rate (per 100,000 people)":"per 100,000 people",
"Consumer price inflation (annual %)":"% per year","Central government debt (% of GDP)":"% of GDP",
"Total reserves including gold (current US$)":"current US$","External balance on goods and services (% of GDP)":"% of GDP"}
API="https://api.worldbank.org/v2/country/{}/indicator/{}?date={}:{}&format=json&per_page=20000"

@st.cache_data(ttl=3600,show_spinner=False)
def get_world_bank(code,indicator,start,end):
    try:
        r=requests.get(API.format(code,indicator,start,end),timeout=20); r.raise_for_status()
        payload=r.json()
        if not isinstance(payload,list) or len(payload)<2 or not payload[1]:
            return pd.DataFrame(columns=["year","value"]),"The API returned no observations."
        df=pd.DataFrame([{"year":int(z["date"]),"value":z.get("value")} for z in payload[1] if z.get("date")])
        if df.empty: return pd.DataFrame(columns=["year","value"]),"No usable observations were returned."
        df["value"]=pd.to_numeric(df["value"],errors="coerce")
        df=df.dropna(subset=["value"]).sort_values("year").reset_index(drop=True)
        return df,(None if len(df) else "The response contained only null values.")
    except requests.Timeout: return pd.DataFrame(columns=["year","value"]),"World Bank request timed out."
    except (requests.RequestException,ValueError,KeyError,TypeError) as e:
        return pd.DataFrame(columns=["year","value"]),f"World Bank request failed: {e}"

def validate(df,indicator):
    x=df.copy(); problems=[]
    if not {"year","value"}.issubset(x.columns): return x,["Table must contain year and value columns."]
    x["year"]=pd.to_numeric(x["year"],errors="coerce"); x["value"]=pd.to_numeric(x["value"],errors="coerce")
    if x.year.isna().any() or ((x.year.dropna()%1)!=0).any(): problems.append("Years must be whole numbers.")
    if x.year.duplicated().any(): problems.append("Years must be unique.")
    if x.value.isna().any(): problems.append("Values must be numeric and nonblank.")
    if not np.isfinite(x.value.dropna()).all(): problems.append("Values must be finite.")
    if indicator=="Life expectancy at birth" and ((x.value<0)|(x.value>120)).any(): problems.append("Life expectancy must be from 0 to 120.")
    if indicator in ["Unemployment, national estimate","Consumer price inflation (annual %)"] and (x.value < -100).any(): problems.append("Percentage values below -100 are invalid.")
    if indicator in ["Crude birth rate (per 1,000 people)","Intentional homicide rate (per 100,000 people)"] and (x.value<0).any(): problems.append("This rate cannot be negative.")
    if indicator in ["GDP per capita (current US$)","Total reserves including gold (current US$)"] and (x.value<0).any(): problems.append("This indicator cannot be negative.")
    return x,problems

def fit_poly(df,degree):
    years=df.year.to_numpy(float); vals=df.value.to_numpy(float); base=float(years.min()); t=years-base
    coef=np.polynomial.polynomial.polyfit(t,vals,degree)
    fitted=np.polynomial.polynomial.polyval(t,coef); residual=vals-fitted
    ssr=float(np.sum(residual**2)); sst=float(np.sum((vals-vals.mean())**2))
    r2=1-ssr/sst if sst else float("nan")
    return base,coef,fitted,residual,r2,float(np.mean(np.abs(residual)))

def parse_expr(source):
    x=sp.Symbol("x")
    funcs={"sin":sp.sin,"cos":sp.cos,"tan":sp.tan,"exp":sp.exp,"log":sp.log,"sqrt":sp.sqrt}
    try:
        e=sp.sympify(source.replace("^","**"),locals={"x":x,"pi":sp.pi,"e":sp.E,**funcs})
        if e.free_symbols-{x}: raise ValueError("Use x as the only variable.")
        return e
    except Exception as exc:
        raise ValueError("Use x, numbers, + - * / ^, and sin/cos/tan/exp/log/sqrt.") from exc

def val(e,xv):
    try:
        z=float(sp.N(e.subs(sp.Symbol("x"),float(xv))))
        return z if math.isfinite(z) else np.nan
    except Exception: return np.nan

def build_pdf(meta,equation,metrics,chart,notes,preview,calcs):
    out=io.BytesIO(); doc=SimpleDocTemplate(out,pagesize=landscape(letter),rightMargin=28,leftMargin=28)
    styles=getSampleStyleSheet(); story=[Paragraph("Hispanic Heritage Historical Data Explorer",styles["Title"]),
        Paragraph(meta,styles["Normal"]),Spacer(1,8),Paragraph("Model",styles["Heading2"]),
        Paragraph(equation,styles["Normal"]),Paragraph(metrics,styles["Normal"]),Spacer(1,8)]
    if chart: story.append(Image(io.BytesIO(chart),width=7*inch,height=3.1*inch))
    story += [Paragraph("Findings and limitations",styles["Heading2"]),Paragraph(notes,styles["BodyText"])]
    if len(preview): story += [Spacer(1,8),Paragraph("Data preview",styles["Heading2"]),Table([preview.columns.tolist()]+preview.astype(str).values.tolist(),repeatRows=1)]
    if len(calcs): story += [Spacer(1,8),Paragraph("Calculated years",styles["Heading2"]),Table([calcs.columns.tolist()]+calcs.astype(str).values.tolist(),repeatRows=1)]
    doc.build(story); return out.getvalue()

# Main controls
st.sidebar.header("🎛️ Data controls")
country=st.sidebar.selectbox("Country",list(COUNTRIES))
indicator=st.sidebar.selectbox("Indicator",list(INDICATORS))
degree=st.sidebar.slider("Polynomial degree",3,8,3)
sample=st.sidebar.slider("Graph sample increment (years)",1,10,1)
horizon=st.sidebar.slider("Forward display horizon (years)",0,50,10)
printer=st.sidebar.checkbox("Printer-friendly view",False)
comparisons=st.sidebar.multiselect("Comparison countries",[c for c in COUNTRIES if c!=country])
today=date.today().year; first,last=today-70,today-1
cc,ic=COUNTRIES[country],INDICATORS[indicator]
source,api_error=get_world_bank(cc,ic,first,last)
if api_error: st.warning(api_error)
st.caption(f"World Bank API · retrieved {date.today().isoformat()} · requested window {first}–{last} inclusive")
st.markdown(f"**Definition:** {DEFS[indicator]}  \n**Unit:** {UNITS[indicator]}  \n**Indicator:** `{ic}` · [World Bank metadata](https://api.worldbank.org/v2/indicator/{ic})")
if country=="Brazil": st.info("Brazil is included as a Latin American comparison; its official language is Portuguese.")
if printer: st.markdown("### Printable report view")
key=f"source_{cc}_{ic}"
if key not in st.session_state: st.session_state[key]=source.copy()
if st.button("↩ Reset to source"):
    st.session_state[key]=source.copy(); st.session_state.pop("calc_state",None); st.rerun()
st.caption("Edit the year/value table below. Changes create a user-modified scenario.")
edited=st.data_editor(st.session_state[key],num_rows="dynamic",use_container_width=True,key=f"edit_{key}",
    column_config={"year":st.column_config.NumberColumn("Year",step=1),"value":st.column_config.NumberColumn("Value")})
data,problems=validate(edited,indicator)
modified=not edited.reset_index(drop=True).equals(source.reset_index(drop=True))
if modified: st.warning("User-modified scenario: calculations and exports use edited values.")
for p in problems: st.error(p)
if not problems: data=data.sort_values("year").reset_index(drop=True)
st.metric("Actual source observations",len(source),f"{source.year.min()}–{source.year.max()}" if len(source) else "No coverage")
fit=None
if not problems and len(data)>=degree+1 and data.year.nunique()>=degree+1: fit=fit_poly(data,degree)
elif not problems: st.warning(f"Degree {degree} needs at least {degree+1} distinct valid years; found {data.year.nunique()}.")

tabs=st.tabs(["📈 Historical model","🧮 Calculate","🌱 Function & calculus lab","📦 Compare & export","📚 Project guide"])
with tabs[0]:
    st.subheader("Historical model")
    if fit:
        base,coef,fitted,resid,r2,mae=fit
        equation="f(t) = "+" + ".join(f"({v:.10g})"+(f"·t^{i}" if i else "") for i,v in enumerate(coef))
        st.code(f"t = year − {base:.0f}\n{equation}")
        a,b,c,d=st.columns(4); a.metric("Degree",degree); b.metric("In-sample R²",f"{r2:.5f}"); c.metric("In-sample MAE",f"{mae:.5g}"); d.metric("Observed mean",f"{data.value.mean():.5g}")
        st.caption(f"In-sample metrics · n={len(data)} · fitted range {data.year.min()}–{data.year.max()} · base year {base:.0f}")
        xx=np.linspace(data.year.min(),data.year.max()+horizon,max(300,(data.year.max()-data.year.min()+horizon)*4+1))
        yy=np.polynomial.polynomial.polyval(xx-base,coef)
        fig,ax=plt.subplots(figsize=(10,4.5)); ax.scatter(data.year,data.value,label="Observed")
        mask=xx<=data.year.max(); ax.plot(xx[mask],yy[mask],label="Fitted curve")
        if horizon: ax.plot(xx[~mask],yy[~mask],"--",label="Extrapolated segment"); ax.axvline(data.year.max(),color="gray",linestyle=":",label="Historical boundary")
        marker=data.iloc[::sample]; ax.scatter(marker.year,np.polynomial.polynomial.polyval(marker.year-base,coef),marker="x",label=f"Markers every {sample} year(s)")
        ax.set(xlabel="Year",ylabel=UNITS[indicator],title=f"{country} — {indicator}"); ax.grid(alpha=.2); ax.legend(); st.pyplot(fig,use_container_width=True)
        st.dataframe(pd.DataFrame({"year":data.year,"observed":data.value,"fitted_at_observed_year":fitted,"residual":resid}),use_container_width=True)
        st.caption("Residuals and MAE are in-sample fit diagnostics, not validated 95% prediction intervals. Extrapolations may be implausible and are not clipped.")
        if len(data)>=max(8,degree+3):
            ntest=max(2,int(np.ceil(.2*len(data)))); train,test=data.iloc[:-ntest],data.iloc[-ntest:]
            if len(train)>=degree+1:
                hb,hc,*_=fit_poly(train,degree); yp=np.polynomial.polynomial.polyval(test.year-hb,hc)
                st.write(f"Chronological holdout MAE (last {ntest} observations; separate earlier-data fit): {np.mean(np.abs(test.value-yp)):.5g} {UNITS[indicator]}.")
        st.write("Residuals:",", ".join(f"{v:.4g}" for v in resid))
    else: st.info("A valid table with at least degree + 1 distinct years is required.")

with tabs[1]:
    st.subheader("Calculate fitted values")
    year=st.number_input("Single year (1950–2100)",1950,2100,2020,1)
    if st.button("Calculate Value"):
        st.session_state["calc_state"]={"years":[int(year)],"sig":(cc,ic,degree,hash(data.to_csv(index=False)))}
    batch=st.radio("Batch input",["Year range","Custom years"],horizontal=True)
    if batch=="Year range":
        q1,q2=st.columns(2); y1=q1.number_input("Start year",1950,2100,2000,key="range_a"); y2=q2.number_input("End year",1950,2100,2020,key="range_b")
        step=st.slider("Range step",1,10,1); requested=list(range(int(y1),int(y2)+1,int(step))) if y2>=y1 else []
        if y2<y1: st.error("End year must not be earlier than start year.")
    else:
        raw=st.text_input("Comma-separated custom years","2000, 2010, 2020"); requested=[]; invalid=[]
        for token in raw.split(","):
            try:
                z=int(token.strip())
                if 1950<=z<=2100: requested.append(z)
                else: invalid.append(token)
            except ValueError: invalid.append(token)
        if invalid: st.error("Invalid year(s); enter whole years from 1950 to 2100: "+", ".join(invalid))
    if st.button("Calculate batch"):
        st.session_state["calc_state"]={"years":sorted(set(requested)),"sig":(cc,ic,degree,hash(data.to_csv(index=False)))}
    saved=st.session_state.get("calc_state"); sig=(cc,ic,degree,hash(data.to_csv(index=False)))
    if saved and saved["sig"]!=sig: st.session_state.pop("calc_state",None); saved=None
    if saved and fit:
        rows=[]
        for yr in saved["years"]:
            est=float(np.polynomial.polynomial.polyval(yr-fit[0],fit[1]))
            rows.append({"Year":yr,"Estimate":est,"Unit":UNITS[indicator],"Classification":"Within fitted range" if data.year.min()<=yr<=data.year.max() else "Outside fitted range","Observed year?":"Yes — fitted estimate is not actual observation" if yr in data.year.values else "No"})
        st.dataframe(pd.DataFrame(rows),use_container_width=True)
        if any(abs(z["Estimate"])>1e12 for z in rows): st.warning("Extreme polynomial estimate: review extrapolation; values are not clipped.")

with tabs[2]:
    st.subheader("Function & calculus lab")
    pathway=st.selectbox("Mathematics pathway",["Honors Algebra 2","Precalculus","Calculus"])
    context=st.selectbox("Context",["Business","Engineering","Medical","Sports science","Biology","Bioengineering","Economic forecasting","Weather","Custom"])
    examples={
    "Business":("Revenue","dollars","quantity","items","100+8*x-0.2*x^2"),
    "Engineering":("Position","meters","time","seconds","x^3-3*x"),
    "Medical":("Concentration","mg/L","time","hours","10*exp(-0.2*x)"),
    "Sports science":("Distance","meters","time","seconds","2*x+sin(x)"),
    "Biology":("Population","cells","time","hours","100*exp(0.1*x)"),
    "Bioengineering":("Signal","volts","time","seconds","sin(x)"),
    "Economic forecasting":("Index","points","time","years","x^2-4*x+10"),
    "Weather":("Temperature","°C","time","hours","20+5*sin(x)"),
    "Custom":("Output","units","input","units","x^2")}
    dep,du,ind,iu,default=examples[context]
    dep=st.text_input("Dependent variable",dep); du=st.text_input("Dependent units",du)
    ind=st.text_input("Independent variable",ind); iu=st.text_input("Independent units",iu)
    choice=st.radio("Function source",["Suggested function","Historical polynomial fit","Custom expression"],horizontal=True)
    if choice=="Historical polynomial fit" and fit:
        x=sp.Symbol("x"); shown=sum(sp.Float(float(c))*(x-float(fit[0]))**i for i,c in enumerate(fit[1])); expression=str(shown)
    elif choice=="Historical polynomial fit": expression=default; st.info("No historical fit yet; using the context suggestion.")
    else: expression=st.text_input("Function using x (supports polynomial, rational, exponential, logarithmic, trigonometric)",default)
    try:
        f=parse_expr(expression); x=sp.Symbol("x"); f1=sp.diff(f,x); f2=sp.diff(f1,x)
        lo,hi=st.slider("Analysis interval",min_value=-20.0,max_value=100.0,value=(0.0,10.0),step=.5)
        if hi<=lo: raise ValueError("Upper endpoint must be greater than lower endpoint.")
        current=st.slider("Current input value",float(lo),float(hi),float((lo+hi)/2),step=.1)
        showf=st.checkbox("Show f(x)",True); show1=st.checkbox("Show f′(x)",True); show2=st.checkbox("Show f″(x)",True)
        st.latex("f(x)="+sp.latex(f))
        if pathway=="Calculus": st.latex("f'(x)="+sp.latex(f1)); st.latex("f''(x)="+sp.latex(f2))
        fv,sv,tv=val(f,current),val(f1,current),val(f2,current)
        avg=(val(f,hi)-val(f,lo))/(hi-lo)
        st.write(f"At {ind}={current:g} {iu}: {dep}={fv:.6g} {du}; instantaneous rate={sv:.6g} {du}/{iu}; second derivative={tv:.6g} {du}/{iu}².")
        st.write(f"Average rate on [{lo:g}, {hi:g}] = {avg:.6g} {du}/{iu}.")
        xs=np.linspace(lo,hi,500); fig,ax=plt.subplots(figsize=(9,4))
        if showf: ax.plot(xs,[val(f,z) for z in xs],label="f(x)")
        if pathway=="Calculus":
            if show1: ax.plot(xs,[val(f1,z) for z in xs],label="f′(x)")
            if show2: ax.plot(xs,[val(f2,z) for z in xs],label="f″(x)")
            ax.scatter([current],[fv],label="Moving point")
            ax.plot(xs,sv*(xs-current)+fv,"--",label="Tangent")
            ax.plot(xs,avg*(xs-lo)+val(f,lo),":",label="Secant")
        ax.set_xlabel(f"{ind} ({iu})"); ax.set_ylabel(f"{dep} ({du})"); ax.grid(alpha=.2); ax.legend(); st.pyplot(fig,use_container_width=True)
        if pathway=="Calculus":
            try:
                crit=[z for z in sp.solve(sp.Eq(f1,0),x) if z.is_real and lo<=float(z)<=hi]
                infl=[z for z in sp.solve(sp.Eq(f2,0),x) if z.is_real and lo<float(z)<hi]
                st.write("Critical-point candidates:",[(str(z),round(val(f,float(z)),6)) for z in crit] or "None found.")
                st.write("Possible inflection candidates:",[(str(z),round(val(f,float(z)),6)) for z in infl] or "None found.")
                st.caption("These are candidates only: verify derivative sign changes and domain continuity. A zero of f′ is not automatically an extremum, nor a zero of f″ automatically an inflection.")
            except Exception: st.info("Exact solving unavailable; plotted values are numerical approximations.")
        elif pathway=="Precalculus":
            st.write("Compare average rates over smaller intervals to study turning behavior and concavity. Degree and coefficients shape the polynomial's end behavior.")
        else:
            st.write(f"Domain is the selected interval [{lo:g}, {hi:g}]. Describe the range from the graph and compare average rates to explain the trend.")
        st.write(f"**Context interpretation:** the output changes at {sv:.5g} {du}/{iu}; the rate changes at {tv:.5g} {du}/{iu}².")
        st.caption("For a position function, f′ represents velocity and f″ acceleration. Other contexts use the same rate-of-change interpretation with their own units. Example simulations are conceptual and scale to the graph.")
    except Exception as exc: st.error(f"Function input error: {exc}")

with tabs[3]:
    st.subheader("Compare countries and export reports")
    others=[]
    for name in comparisons:
        d,e=get_world_bank(COUNTRIES[name],ic,first,last)
        if len(d): d["country"]=name; others.append(d)
    if others:
        comp=pd.concat(others,ignore_index=True); st.line_chart(comp.pivot(index="year",columns="country",values="value"))
        st.caption("Country series can have different coverage. Missing years are gaps, not zero.")
        st.dataframe(comp,use_container_width=True)
    else: st.info("Select comparison countries in the sidebar.")
    summary=pd.DataFrame([{"Country":country,"Indicator":indicator,"Code":ic,"Degree":degree,"Modified scenario":modified,"Count":len(data),"Coverage":f"{data.year.min()}–{data.year.max()}" if len(data) else "No data","Retrieved":date.today().isoformat()}])
    calc_df=pd.DataFrame()
    saved=st.session_state.get("calc_state")
    if saved and fit:
        calc_df=pd.DataFrame([{"year":y,"estimate":float(np.polynomial.polynomial.polyval(y-fit[0],fit[1])),"unit":UNITS[indicator]} for y in saved["years"]])
    st.download_button("Download working data CSV",data.to_csv(index=False).encode(),"working_data.csv","text/csv")
    excel=io.BytesIO()
    with pd.ExcelWriter(excel,engine="xlsxwriter") as writer:
        summary.to_excel(writer,index=False,sheet_name="Summary"); data.to_excel(writer,index=False,sheet_name="Working data"); calc_df.to_excel(writer,index=False,sheet_name="Calculated years")
    st.download_button("Download Excel workbook",excel.getvalue(),"explorer_results.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    imagebuf=io.BytesIO(); fig,ax=plt.subplots(figsize=(9,4))
    if len(data): ax.scatter(data.year,data.value,label="Observed")
    if fit:
        xplot=np.linspace(data.year.min(),data.year.max()+horizon,300); ax.plot(xplot,np.polynomial.polynomial.polyval(xplot-fit[0],fit[1]),label="Polynomial")
    ax.set_title(f"{country} — {indicator}"); ax.set_xlabel("Year"); ax.set_ylabel(UNITS[indicator]); ax.legend(); fig.tight_layout(); fig.savefig(imagebuf,format="png",dpi=140)
    metrics=f"n={len(data)}; coverage {data.year.min()}–{data.year.max()}" if len(data) else "No data"
    pdf=build_pdf(f"{country} | {indicator} | Retrieved {date.today().isoformat()} | Edited={modified}",
        f"Centered degree-{degree} polynomial" if fit else "No model fitted",metrics,imagebuf.getvalue(),
        "Descriptive model only; not causal. In-sample MAE is not a prediction interval. Extrapolation may be implausible.",
        data.head(18),calc_df)
    st.download_button("Download PDF report",pdf,"explorer_report.pdf","application/pdf")

with tabs[4]:
    st.subheader("Project guide and mathematical assumptions")
    st.markdown("""
**Data flow:** sidebar selections → World Bank API → cached source data → editable/validated scenario → centered polynomial least-squares model → charts, estimates, comparisons, exports.

**Centered time:** `t = year − base year`. This same transformation is used for fitting and prediction. A degree-d model requires at least d+1 distinct years. R² and MAE are in-sample; the chronological holdout is a separate score.

**Course pathways:** Algebra 2 emphasizes domain window, graph trends, and average rates. Precalculus adds degree/coefficient effects and concavity ideas. Calculus displays symbolic first/second derivatives, tangent/secant lines, and critical/inflection candidates. Candidate points require sign-change and domain checks.

**Limitations:** The polynomial describes a pattern; it does not establish historical causes. Extrapolation may be unrealistic. No confidence or prediction interval is claimed. World Bank coverage varies by series and country. Missing data are never replaced with random values.
""")
