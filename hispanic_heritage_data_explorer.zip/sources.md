# Sources and indicator metadata

Primary source: **World Bank Indicators API**.

API request pattern:
`https://api.worldbank.org/v2/country/{ISO2}/indicator/{CODE}?date={START}:{END}&format=json&per_page=20000`

## Countries
Mexico MX; Brazil BR; Argentina AR; Colombia CO; Chile CL; Peru PE; Venezuela VE; Ecuador EC; Uruguay UY. Brazil is included as a Latin American comparison; Portuguese is its official language.

## Indicators

| Indicator | World Bank code | Meaning and unit |
|---|---|---|
| Life expectancy at birth | SP.DYN.LE00.IN | Expected years at birth under current age-specific mortality rates; years |
| Unemployment, national estimate | SL.UEM.TOTL.NE.ZS | Unemployed people as a percentage of the labor force |
| GDP per capita, current US$ | NY.GDP.PCAP.CD | GDP divided by population, current US dollars per person; not average wealth or household income |
| Crude birth rate | SP.DYN.CBRT.IN | Live births per 1,000 people; a rate, not a birth count |
| Net migration | SM.POP.NETM | Net number of migrants; not an emigration count |
| Intentional homicide rate | VC.IHR.PSRC.P5 | Intentional homicide victims per 100,000 people |
| Consumer price inflation | FP.CPI.TOTL.ZG | Annual percentage change in consumer price index |
| Central government debt | GC.DOD.TOTL.GD.ZS | Central government debt as a percentage of GDP |
| Total reserves including gold | FI.RES.TOTL.CD | Total reserves including gold, current US dollars |
| External balance on goods and services | NE.RSB.GNFS.ZS | External balance on goods and services as a percentage of GDP |

The app requests current year minus 70 through current year minus 1, inclusive. It reports actual returned non-null observation count and coverage; it does not promise 70 observations. Retrieval date is displayed in the app. Values and definitions may be revised.

Indicator metadata endpoint:
`https://api.worldbank.org/v2/indicator/{CODE}`

Function-lab examples are classroom mathematical models, not forecasts or professional advice. Missing data are not fabricated.
