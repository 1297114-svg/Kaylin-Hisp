# Hispanic Heritage Historical Data Explorer

A Streamlit classroom project for World Bank historical indicators, editable scenarios, centered polynomial fitting, a context-based function/calculus lab, country comparisons, and CSV/XLSX/PDF exports.

## Research question and project choices
The prompt leaves the research question and selected countries/indicator/pathway open. Choose these as a team and record them in your presentation. The app includes nine countries, ten indicators, and three math pathways.

## Run locally
```bash
pip install -r requirements.txt
python -m streamlit run app.py
```

## GitHub and Streamlit Community Cloud
1. Create a GitHub repository and upload `app.py`, `requirements.txt`, `README.md`, and `sources.md` to the repository root.
2. Commit and push the files.
3. In Streamlit Community Cloud, create a new app, select the repository and branch, set the main file path to `app.py`, and deploy.
4. Check deployment logs if an error appears. The public World Bank API does not require credentials.

## Render
Create a **Python Web Service** connected to your GitHub repository.

Build command:
`pip install -r requirements.txt`

Start command (one line):
`python -m streamlit run app.py --server.address=0.0.0.0 --server.port=$PORT`

## Verification checklist
- Check country, indicator code, definition, unit, API link, retrieval date, count, and actual coverage.
- Edit data and confirm the user-modified scenario warning; click Reset to source.
- Try duplicate years, fractional years, blank values, non-numeric values, and indicator-specific invalid values.
- Set a polynomial degree with too few observations and confirm the app explains degree + 1.
- Inspect centered equation, base year, in-sample R²/MAE, residuals, and holdout score.
- Calculate a year singly and in a batch; verify the estimates match.
- Test invalid custom years and reversed range endpoints.
- Change country, indicator, degree, graph sample increment, forecast horizon, comparisons, printer view, context, pathway, function, and interval.
- Confirm CSV is a CSV; Excel contains Summary, Working data, and Calculated years; PDF opens as a PDF.
- Test API timeout/empty response behavior. No fabricated values should appear.
- After deployment, repeat checks and inspect Streamlit/Render logs.

## Common errors
- `ModuleNotFoundError`: check that requirements.txt is in the repository root and redeploy.
- Empty data: some World Bank series have gaps or missing country-years; inspect the indicator metadata page and retry network access.
- Too few years: lower polynomial degree or choose a series with enough distinct observations.
- Function parsing error: use `x`, arithmetic operators, powers, and `sin`, `cos`, `tan`, `exp`, `log`, or `sqrt`.
- Render port error: use the exact start command above and bind to `0.0.0.0`.
- Wrong deployed app: check repository, branch, root directory, and main file path.

## Dependencies and testing note
`requirements.txt` intentionally uses unpinned, minimal package names for Streamlit deployment. Versions are resolved by the deployment environment. This source was generated but not executed in this chat environment; do not describe it as runtime-tested until you run the verification checklist.
